﻿Imports System.Runtime.InteropServices
Imports GregsStack.InputSimulatorStandard
Imports GregsStack.InputSimulatorStandard.Native

Public Class classInput
    '(D)A[5](U)A
    Public Declare Sub mouse_event Lib "user32" (ByVal dwFlags As UInteger,
                                                 ByVal dx As UInteger, ByVal dy As UInteger,
                                                 ByVal dwData As UInteger, ByVal dwExtraInfo As Integer)
    Public Shared Sub SendText(ByRef Text As String) 'extra
        Try
            Dim isim As New InputSimulator
            isim.Keyboard.TextEntry(Text)
        Catch ex As Exception
            'MsgBox(Text + ex.ToString)
        End Try
    End Sub

    Public Shared Sub SendKeystrokeDown(ByRef hWnd As Integer, 'window handle
                                        ByRef WM_Keyaction As Integer,  'keydown or keyup
                                        ByRef VirtualKeyMessage As Integer, 'message like W or S
                                        ByRef lparam As Long, 'extra
                                        ByRef wparam As Long) 'extra
        Try
            If hWnd = 0 Then
                MsgBox("No Window!")
            Else
                'If to see if its for mouse input cause input program dont work for mouse input on most elements
                If VirtualKeyMessage = 1 Then
                    mouse_event(&H2, 0, 0, 0, 0)
                Else
                    Dim isim As New InputSimulator 'to instantiate input for window
                    isim.Keyboard.KeyDown(VirtualKeyMessage) 'keydown not working NOT WORKING IN NOTEPAD

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    'Only issue here is that it cant send input into background process, or unfocused window for multitasking. 
    Public Shared Sub SendKeystrokeUp(ByRef hWnd As Integer, ByRef WM_Keyaction As Integer, ByRef VirtualKeyMessage As Integer, ByRef lparam As Long, ByRef wparam As Long)
        Try
            'If to see if its for mouse input cause input program dont work for mouse input on most elements
            If VirtualKeyMessage = 1 Then
                mouse_event(&H4, 0, 0, 0, 0)
            Else
                Dim isim As New InputSimulator 'to instantiate input for window
                isim.Keyboard.KeyUp(VirtualKeyMessage) 'keydown not working NOT WORKING IN NOTEPAD
            End If
        Catch ex As Exception
            MsgBox("Probably wrong key:"(ex.ToString))
        End Try
    End Sub
End Class
