﻿Public Class Hotkey
#Region "Declarations - WinAPI, Hotkey constant and Modifier Enum"
    ''' <summary>
    ''' Declaration of winAPI function wrappers. The winAPI functions are used to register / unregister a hotkey
    ''' </summary>
    Private Declare Function RegisterHotKey Lib "user32" _
        (ByVal hwnd As IntPtr, ByVal id As Integer, ByVal fsModifiers As Integer, ByVal vk As Integer) As Integer

    Private Declare Function UnregisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer) As Integer

    Public Const WM_HOTKEY As Integer = &H312

    Enum KeyModifier
        None = 0
        Alt = &H1
        Control = &H2
        Shift = &H4
        Winkey = &H8
    End Enum 'This enum is just to make it easier to call the registerHotKey function: The modifier integer codes are replaced by a friendly "Alt","Shift" etc.
#End Region


#Region "Hotkey registration, unregistration and handling"
    Public Shared Sub registerHotkey(ByRef sourceForm As Form, ByVal hotkeyID As Integer, ByVal triggerKey As String, ByVal modifier As KeyModifier)
        RegisterHotKey(sourceForm.Handle, hotkeyID, modifier, Asc(triggerKey.ToUpper))
    End Sub
    'For virtual Keys
    Public Shared Sub registerVirtualHotkey(ByRef sourceForm As Form, ByVal hotkeyID As Integer, ByVal triggerKey As Integer, ByVal modifier As KeyModifier)
        RegisterHotKey(sourceForm.Handle, hotkeyID, modifier, triggerKey)
    End Sub
    Public Shared Sub unregisterHotkeys(ByRef sourceForm As Form)
        UnregisterHotKey(sourceForm.Handle, 1)  'Remember to call unregisterHotkeys() when closing your application.\
        UnregisterHotKey(sourceForm.Handle, 2)
    End Sub

    Public Shared Sub unregisterHotkey(ByRef sourceForm As Form, ByRef id As Integer)
        UnregisterHotKey(sourceForm.Handle, id)
    End Sub
    'The first parameter is the sourceform, essentially your main form.
    'The second parameter is a number ID for the hotkey registration, this can be any integer though with some limitations.
    'Next parameter is the key that needs to be pressed,
    'and the fourth and final is the modifier (alt, shift, control, winkey) if any.

#End Region

#Region "Cases for hotkey ID's"
    Public Shared Sub handleHotKeyEvent(ByVal hotkeyID As IntPtr)
        Select Case hotkeyID
            Case 1
                MainForm.macroLoop() 'Starts macro by checking if loop is checked
            Case 2
                MainForm.boolBoxLoop = False 'stops loop
            Case 3
                MsgBox("The hotkey ALT+R (ID: 3) was pressed")




            Case 2000
                MsgBox("Slot 1 Started")
            Case 2001
                MsgBox("Slot 1 stopped")
        End Select
    End Sub
#End Region

#Region "Hotkey Button Function"
    '1 Gets modifier
    Public Shared Sub getHotkeyButtonKeyDown(e As KeyEventArgs)
        'Need modifier to get processed IF it's detected
        If e.Modifiers = Keys.Control Then
            intHotkeyGetModifier = &H2
        ElseIf e.Modifiers = Keys.Alt Then
            intHotkeyGetModifier = &H1
        ElseIf e.Modifiers = Keys.Shift Then
            intHotkeyGetModifier = &H4
        ElseIf e.Modifiers = Keys.None Then
            intHotkeyGetModifier = 0
        End If

    End Sub
    '2 Gets key
    Public Shared Sub getHotkeyButtonKeyUp(e As KeyEventArgs, MyForm As Form, ID As Integer)
        'if to see if esc is pressed
        If e.KeyCode = Keys.Escape Then
            boolGetHotkey = False
            btnText = "No Key" 'Edit
            intHotkeyGetModifier = 0
            Hotkey.unregisterHotkey(MyForm, ID) 'Edit
        Else
            'Changes Button Text
            btnText = (e.KeyData.ToString) 'Edit
            'Sets register Key
            Hotkey.registerVirtualHotkey(MyForm, ID, e.KeyCode, intHotkeyGetModifier) 'Edit
            'Stops hotkey get
            boolGetHotkey = False
        End If
    End Sub

#End Region
End Class
