﻿Imports System.Runtime.InteropServices

Module moduleVariables
    'module is used to share variables/code across all items/classes
    Public Enum KeyEventType As Int32
        WM_SETTEXT = &HC
        WM_KEYDOWN = &H100
        WM_KEYUP = &H101
    End Enum 'For keydown, keyup, stuff
    Public intHotkeyGetModifier As Integer = 0
    Public boolGetHotkey As Boolean 'boolean to get hotkey
    Public btnText As String 'string to set button text
End Module
