﻿Imports System.Runtime.InteropServices
Imports GregsStack.InputSimulatorStandard
Imports GregsStack.InputSimulatorStandard.Native

Public Class classInput
    '(D)A[5](U)A
    Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Integer, ByVal Msg As Integer, ByVal wParam As Long, ByVal lParam As Long) As Integer

    Public Shared Sub SendKeystrokeDown(ByRef hWnd As Integer, 'window handle
                                        ByRef WM_Keyaction As Integer,  'keydown or keyup
                                        ByRef VirtualKeyMessage As Integer, 'message
                                        ByRef lparam As Long, 'extra
                                        ByRef wparam As Long) 'extra

        If hWnd = 0 Then
            MsgBox("No Window!")
        Else
            'SendMessage(hWnd, WM_KEYDOWN, New IntPtr(Keys.A), IntPtr.Zero) 'this is the key to send input while unfocused
            Dim isim As New InputSimulator 'to instantiate input for window
            isim.Keyboard.KeyDown(VirtualKeyMessage) 'keydown not working NOT WORKING IN NOTEPAD
        End If
    End Sub
    'Only issue here is that it cant send input into background process, or unfocused window for multitasking. 
    Public Shared Sub SendKeystrokeUp(ByRef hWnd As Integer, ByRef WM_Keyaction As Integer, ByRef VirtualKeyMessage As Integer, ByRef lparam As Long, ByRef wparam As Long)
        If hWnd = 0 Then
            MsgBox("No Window!")
        Else
            'SendMessage(hWnd, WM_KEYUP, New IntPtr(Keys.A), IntPtr.Zero) 'this is the key to send input while unfocused
            Dim isim As New InputSimulator 'to instantiate input for window
            isim.Keyboard.KeyUp(VirtualKeyMessage) 'Simulates keypress as well NOT WORKING IN GAME
        End If
    End Sub
End Class
