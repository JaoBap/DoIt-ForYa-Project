﻿Public Class classSaveSettings
#Region "Hotkey Settings Save"

#End Region
End Class
