﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.lblInput = New System.Windows.Forms.Label()
        Me.tbMenu = New System.Windows.Forms.TabControl()
        Me.tbpgMacro = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnLoadSelectedMacro = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSaveSelectedMacro = New System.Windows.Forms.Button()
        Me.txtWindowCaption = New System.Windows.Forms.TextBox()
        Me.btnCapture = New System.Windows.Forms.Button()
        Me.chkLoop = New System.Windows.Forms.CheckBox()
        Me.lblMacroname = New System.Windows.Forms.Label()
        Me.tbpgLoad = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.chkLoop1 = New System.Windows.Forms.CheckBox()
        Me.btnStop1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.label1231 = New System.Windows.Forms.Label()
        Me.btnStart1 = New System.Windows.Forms.Button()
        Me.btnLoadMacro = New System.Windows.Forms.Button()
        Me.gridLoadedMacros = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.File_Location_Loaded = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.State = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnRemoveSavedMacro = New System.Windows.Forms.Button()
        Me.btnLoadSavedMacro = New System.Windows.Forms.Button()
        Me.gridFavMacros = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.File_Location = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gridSavedMacros = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileLocation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnSaveLoadout = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnUnFav = New System.Windows.Forms.Button()
        Me.btnFav = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbpgSettings = New System.Windows.Forms.TabPage()
        Me.btnDefaultSettings = New System.Windows.Forms.Button()
        Me.btnSaveSettings = New System.Windows.Forms.Button()
        Me.tabSettings = New System.Windows.Forms.TabControl()
        Me.tbSettings = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnHotkeyStop = New System.Windows.Forms.Button()
        Me.btnHotkeyStart = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbpgHelp = New System.Windows.Forms.TabPage()
        Me.LoadedMacrosDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnStart = New System.Windows.Forms.Button()
        Me.lblStartHotkey = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.lblStopHotkey = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblPauseHotkey = New System.Windows.Forms.Label()
        Me.filedialogLoadMacroMain = New System.Windows.Forms.OpenFileDialog()
        Me.btnTest = New System.Windows.Forms.Button()
        Me.filedialogSaveMacroMain = New System.Windows.Forms.SaveFileDialog()
        Me.FavoriteMacrosDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DatabaseLoadedMacrosDataSet = New Macro_Project.databaseLoadedMacrosDataSet()
        Me.DatabaseLoadedMacrosDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.tbMenu.SuspendLayout()
        Me.tbpgMacro.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tbpgLoad.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.gridLoadedMacros, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gridFavMacros, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gridSavedMacros, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbpgSettings.SuspendLayout()
        Me.tabSettings.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.LoadedMacrosDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FavoriteMacrosDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DatabaseLoadedMacrosDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DatabaseLoadedMacrosDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(6, 25)
        Me.txtInput.Multiline = True
        Me.txtInput.Name = "txtInput"
        Me.txtInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInput.Size = New System.Drawing.Size(765, 368)
        Me.txtInput.TabIndex = 0
        '
        'lblInput
        '
        Me.lblInput.AutoSize = True
        Me.lblInput.Location = New System.Drawing.Point(-3, 0)
        Me.lblInput.Name = "lblInput"
        Me.lblInput.Size = New System.Drawing.Size(31, 13)
        Me.lblInput.TabIndex = 1
        Me.lblInput.Text = "Input"
        '
        'tbMenu
        '
        Me.tbMenu.Controls.Add(Me.tbpgMacro)
        Me.tbMenu.Controls.Add(Me.tbpgLoad)
        Me.tbMenu.Controls.Add(Me.tbpgSettings)
        Me.tbMenu.Controls.Add(Me.tbpgHelp)
        Me.tbMenu.Location = New System.Drawing.Point(0, -1)
        Me.tbMenu.Name = "tbMenu"
        Me.tbMenu.SelectedIndex = 0
        Me.tbMenu.Size = New System.Drawing.Size(802, 456)
        Me.tbMenu.TabIndex = 2
        '
        'tbpgMacro
        '
        Me.tbpgMacro.Controls.Add(Me.GroupBox1)
        Me.tbpgMacro.Location = New System.Drawing.Point(4, 22)
        Me.tbpgMacro.Name = "tbpgMacro"
        Me.tbpgMacro.Padding = New System.Windows.Forms.Padding(3)
        Me.tbpgMacro.Size = New System.Drawing.Size(794, 430)
        Me.tbpgMacro.TabIndex = 0
        Me.tbpgMacro.Text = "Macro"
        Me.tbpgMacro.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnLoadSelectedMacro)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.btnSaveSelectedMacro)
        Me.GroupBox1.Controls.Add(Me.txtWindowCaption)
        Me.GroupBox1.Controls.Add(Me.btnCapture)
        Me.GroupBox1.Controls.Add(Me.chkLoop)
        Me.GroupBox1.Controls.Add(Me.lblMacroname)
        Me.GroupBox1.Controls.Add(Me.lblInput)
        Me.GroupBox1.Controls.Add(Me.txtInput)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(777, 421)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'btnLoadSelectedMacro
        '
        Me.btnLoadSelectedMacro.Location = New System.Drawing.Point(34, 0)
        Me.btnLoadSelectedMacro.Name = "btnLoadSelectedMacro"
        Me.btnLoadSelectedMacro.Size = New System.Drawing.Size(58, 19)
        Me.btnLoadSelectedMacro.TabIndex = 13
        Me.btnLoadSelectedMacro.Text = "Load"
        Me.btnLoadSelectedMacro.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 404)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Window:"
        '
        'btnSaveSelectedMacro
        '
        Me.btnSaveSelectedMacro.Location = New System.Drawing.Point(715, 0)
        Me.btnSaveSelectedMacro.Name = "btnSaveSelectedMacro"
        Me.btnSaveSelectedMacro.Size = New System.Drawing.Size(58, 19)
        Me.btnSaveSelectedMacro.TabIndex = 11
        Me.btnSaveSelectedMacro.Text = "Save"
        Me.btnSaveSelectedMacro.UseVisualStyleBackColor = True
        '
        'txtWindowCaption
        '
        Me.txtWindowCaption.Location = New System.Drawing.Point(55, 401)
        Me.txtWindowCaption.Name = "txtWindowCaption"
        Me.txtWindowCaption.Size = New System.Drawing.Size(519, 20)
        Me.txtWindowCaption.TabIndex = 10
        Me.txtWindowCaption.Text = "No Window!"
        '
        'btnCapture
        '
        Me.btnCapture.Location = New System.Drawing.Point(580, 399)
        Me.btnCapture.Name = "btnCapture"
        Me.btnCapture.Size = New System.Drawing.Size(129, 23)
        Me.btnCapture.TabIndex = 9
        Me.btnCapture.Text = "Capture Last Window"
        Me.btnCapture.UseVisualStyleBackColor = True
        '
        'chkLoop
        '
        Me.chkLoop.AutoSize = True
        Me.chkLoop.Location = New System.Drawing.Point(715, 401)
        Me.chkLoop.Name = "chkLoop"
        Me.chkLoop.Size = New System.Drawing.Size(56, 17)
        Me.chkLoop.TabIndex = 7
        Me.chkLoop.Text = "Loop?"
        Me.chkLoop.UseVisualStyleBackColor = True
        '
        'lblMacroname
        '
        Me.lblMacroname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblMacroname.AutoSize = True
        Me.lblMacroname.Location = New System.Drawing.Point(98, 0)
        Me.lblMacroname.Name = "lblMacroname"
        Me.lblMacroname.Size = New System.Drawing.Size(62, 13)
        Me.lblMacroname.TabIndex = 2
        Me.lblMacroname.Text = "macroname"
        Me.lblMacroname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tbpgLoad
        '
        Me.tbpgLoad.Controls.Add(Me.GroupBox4)
        Me.tbpgLoad.Controls.Add(Me.btnLoadMacro)
        Me.tbpgLoad.Controls.Add(Me.gridLoadedMacros)
        Me.tbpgLoad.Controls.Add(Me.btnRemoveSavedMacro)
        Me.tbpgLoad.Controls.Add(Me.btnLoadSavedMacro)
        Me.tbpgLoad.Controls.Add(Me.gridFavMacros)
        Me.tbpgLoad.Controls.Add(Me.gridSavedMacros)
        Me.tbpgLoad.Controls.Add(Me.btnSaveLoadout)
        Me.tbpgLoad.Controls.Add(Me.Label7)
        Me.tbpgLoad.Controls.Add(Me.Label6)
        Me.tbpgLoad.Controls.Add(Me.btnUnFav)
        Me.tbpgLoad.Controls.Add(Me.btnFav)
        Me.tbpgLoad.Controls.Add(Me.Label5)
        Me.tbpgLoad.Location = New System.Drawing.Point(4, 22)
        Me.tbpgLoad.Name = "tbpgLoad"
        Me.tbpgLoad.Size = New System.Drawing.Size(794, 430)
        Me.tbpgLoad.TabIndex = 2
        Me.tbpgLoad.Text = "Macro Pages"
        Me.tbpgLoad.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.chkLoop1)
        Me.GroupBox4.Controls.Add(Me.btnStop1)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.label1231)
        Me.GroupBox4.Controls.Add(Me.btnStart1)
        Me.GroupBox4.Location = New System.Drawing.Point(622, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(159, 376)
        Me.GroupBox4.TabIndex = 17
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Hotkeys for Slotted Macros"
        '
        'chkLoop1
        '
        Me.chkLoop1.AutoSize = True
        Me.chkLoop1.Location = New System.Drawing.Point(6, 58)
        Me.chkLoop1.Name = "chkLoop1"
        Me.chkLoop1.Size = New System.Drawing.Size(50, 17)
        Me.chkLoop1.TabIndex = 4
        Me.chkLoop1.Text = "Loop"
        Me.chkLoop1.UseVisualStyleBackColor = True
        '
        'btnStop1
        '
        Me.btnStop1.Location = New System.Drawing.Point(76, 34)
        Me.btnStop1.Name = "btnStop1"
        Me.btnStop1.Size = New System.Drawing.Size(60, 23)
        Me.btnStop1.TabIndex = 3
        Me.btnStop1.Text = "Ctrl + 2"
        Me.btnStop1.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(73, 18)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Stop"
        '
        'label1231
        '
        Me.label1231.AutoSize = True
        Me.label1231.Location = New System.Drawing.Point(6, 18)
        Me.label1231.Name = "label1231"
        Me.label1231.Size = New System.Drawing.Size(29, 13)
        Me.label1231.TabIndex = 1
        Me.label1231.Text = "Start"
        '
        'btnStart1
        '
        Me.btnStart1.Location = New System.Drawing.Point(6, 34)
        Me.btnStart1.Name = "btnStart1"
        Me.btnStart1.Size = New System.Drawing.Size(60, 23)
        Me.btnStart1.TabIndex = 0
        Me.btnStart1.Text = "Ctrl + 1"
        Me.btnStart1.UseVisualStyleBackColor = True
        '
        'btnLoadMacro
        '
        Me.btnLoadMacro.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnLoadMacro.Location = New System.Drawing.Point(207, 390)
        Me.btnLoadMacro.Name = "btnLoadMacro"
        Me.btnLoadMacro.Size = New System.Drawing.Size(164, 34)
        Me.btnLoadMacro.TabIndex = 15
        Me.btnLoadMacro.Text = "Load into Macro tab"
        Me.btnLoadMacro.UseVisualStyleBackColor = False
        '
        'gridLoadedMacros
        '
        Me.gridLoadedMacros.AllowUserToAddRows = False
        Me.gridLoadedMacros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridLoadedMacros.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.File_Location_Loaded, Me.State})
        Me.gridLoadedMacros.Location = New System.Drawing.Point(377, 21)
        Me.gridLoadedMacros.Name = "gridLoadedMacros"
        Me.gridLoadedMacros.ReadOnly = True
        Me.gridLoadedMacros.RowHeadersVisible = False
        Me.gridLoadedMacros.Size = New System.Drawing.Size(238, 363)
        Me.gridLoadedMacros.TabIndex = 14
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.HeaderText = "Macro Name"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'File_Location_Loaded
        '
        Me.File_Location_Loaded.HeaderText = "File Location"
        Me.File_Location_Loaded.Name = "File_Location_Loaded"
        Me.File_Location_Loaded.ReadOnly = True
        Me.File_Location_Loaded.Visible = False
        '
        'State
        '
        Me.State.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.State.HeaderText = "State"
        Me.State.Name = "State"
        Me.State.ReadOnly = True
        '
        'btnRemoveSavedMacro
        '
        Me.btnRemoveSavedMacro.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnRemoveSavedMacro.Location = New System.Drawing.Point(88, 390)
        Me.btnRemoveSavedMacro.Name = "btnRemoveSavedMacro"
        Me.btnRemoveSavedMacro.Size = New System.Drawing.Size(82, 37)
        Me.btnRemoveSavedMacro.TabIndex = 13
        Me.btnRemoveSavedMacro.Text = "Remove Macro"
        Me.btnRemoveSavedMacro.UseVisualStyleBackColor = False
        '
        'btnLoadSavedMacro
        '
        Me.btnLoadSavedMacro.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnLoadSavedMacro.Location = New System.Drawing.Point(6, 390)
        Me.btnLoadSavedMacro.Name = "btnLoadSavedMacro"
        Me.btnLoadSavedMacro.Size = New System.Drawing.Size(82, 37)
        Me.btnLoadSavedMacro.TabIndex = 12
        Me.btnLoadSavedMacro.Text = "Add Macro to Load List"
        Me.btnLoadSavedMacro.UseVisualStyleBackColor = False
        '
        'gridFavMacros
        '
        Me.gridFavMacros.AllowUserToAddRows = False
        Me.gridFavMacros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridFavMacros.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.File_Location})
        Me.gridFavMacros.Location = New System.Drawing.Point(207, 21)
        Me.gridFavMacros.Name = "gridFavMacros"
        Me.gridFavMacros.ReadOnly = True
        Me.gridFavMacros.RowHeadersVisible = False
        Me.gridFavMacros.Size = New System.Drawing.Size(164, 363)
        Me.gridFavMacros.TabIndex = 11
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn2.HeaderText = "Macro"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'File_Location
        '
        Me.File_Location.HeaderText = "File Location"
        Me.File_Location.Name = "File_Location"
        Me.File_Location.ReadOnly = True
        Me.File_Location.Visible = False
        '
        'gridSavedMacros
        '
        Me.gridSavedMacros.AllowUserToAddRows = False
        Me.gridSavedMacros.AllowUserToDeleteRows = False
        Me.gridSavedMacros.AllowUserToResizeRows = False
        Me.gridSavedMacros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridSavedMacros.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.FileLocation})
        Me.gridSavedMacros.Location = New System.Drawing.Point(6, 21)
        Me.gridSavedMacros.Name = "gridSavedMacros"
        Me.gridSavedMacros.RowHeadersVisible = False
        Me.gridSavedMacros.Size = New System.Drawing.Size(164, 363)
        Me.gridSavedMacros.TabIndex = 10
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn1.HeaderText = "Macro"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'FileLocation
        '
        Me.FileLocation.HeaderText = "File Location"
        Me.FileLocation.Name = "FileLocation"
        Me.FileLocation.ReadOnly = True
        Me.FileLocation.Visible = False
        '
        'btnSaveLoadout
        '
        Me.btnSaveLoadout.Location = New System.Drawing.Point(698, 388)
        Me.btnSaveLoadout.Name = "btnSaveLoadout"
        Me.btnSaveLoadout.Size = New System.Drawing.Size(83, 36)
        Me.btnSaveLoadout.TabIndex = 8
        Me.btnSaveLoadout.Text = "Save Current Loadout"
        Me.btnSaveLoadout.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(374, 3)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Slotted Macros"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(204, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Favorite Macros"
        '
        'btnUnFav
        '
        Me.btnUnFav.Location = New System.Drawing.Point(176, 200)
        Me.btnUnFav.Name = "btnUnFav"
        Me.btnUnFav.Size = New System.Drawing.Size(25, 172)
        Me.btnUnFav.TabIndex = 4
        Me.btnUnFav.Text = "<"
        Me.btnUnFav.UseVisualStyleBackColor = True
        '
        'btnFav
        '
        Me.btnFav.Location = New System.Drawing.Point(176, 22)
        Me.btnFav.Name = "btnFav"
        Me.btnFav.Size = New System.Drawing.Size(25, 172)
        Me.btnFav.TabIndex = 3
        Me.btnFav.Text = ">"
        Me.btnFav.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Saved Macros"
        '
        'tbpgSettings
        '
        Me.tbpgSettings.Controls.Add(Me.btnDefaultSettings)
        Me.tbpgSettings.Controls.Add(Me.btnSaveSettings)
        Me.tbpgSettings.Controls.Add(Me.tabSettings)
        Me.tbpgSettings.Location = New System.Drawing.Point(4, 22)
        Me.tbpgSettings.Name = "tbpgSettings"
        Me.tbpgSettings.Padding = New System.Windows.Forms.Padding(3)
        Me.tbpgSettings.Size = New System.Drawing.Size(794, 430)
        Me.tbpgSettings.TabIndex = 1
        Me.tbpgSettings.Text = "Settings"
        Me.tbpgSettings.UseVisualStyleBackColor = True
        '
        'btnDefaultSettings
        '
        Me.btnDefaultSettings.Location = New System.Drawing.Point(539, 5)
        Me.btnDefaultSettings.Name = "btnDefaultSettings"
        Me.btnDefaultSettings.Size = New System.Drawing.Size(161, 22)
        Me.btnDefaultSettings.TabIndex = 1
        Me.btnDefaultSettings.Text = "Default Settings"
        Me.btnDefaultSettings.UseVisualStyleBackColor = True
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Location = New System.Drawing.Point(702, 5)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(82, 22)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'tabSettings
        '
        Me.tabSettings.Controls.Add(Me.tbSettings)
        Me.tabSettings.Controls.Add(Me.TabPage2)
        Me.tabSettings.Location = New System.Drawing.Point(3, 33)
        Me.tabSettings.Name = "tabSettings"
        Me.tabSettings.SelectedIndex = 0
        Me.tabSettings.Size = New System.Drawing.Size(785, 391)
        Me.tabSettings.TabIndex = 0
        '
        'tbSettings
        '
        Me.tbSettings.Location = New System.Drawing.Point(4, 22)
        Me.tbSettings.Name = "tbSettings"
        Me.tbSettings.Padding = New System.Windows.Forms.Padding(3)
        Me.tbSettings.Size = New System.Drawing.Size(777, 365)
        Me.tbSettings.TabIndex = 0
        Me.tbSettings.Text = "Basic"
        Me.tbSettings.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(777, 365)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Hotkeys"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(151, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Press the hotkey to re-assign it"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnHotkeyStop)
        Me.GroupBox3.Controls.Add(Me.btnHotkeyStart)
        Me.GroupBox3.Location = New System.Drawing.Point(89, 20)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(77, 369)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Hotkey"
        '
        'btnHotkeyStop
        '
        Me.btnHotkeyStop.Location = New System.Drawing.Point(5, 42)
        Me.btnHotkeyStop.Name = "btnHotkeyStop"
        Me.btnHotkeyStop.Size = New System.Drawing.Size(63, 23)
        Me.btnHotkeyStop.TabIndex = 2
        Me.btnHotkeyStop.Text = "F3"
        Me.btnHotkeyStop.UseVisualStyleBackColor = True
        '
        'btnHotkeyStart
        '
        Me.btnHotkeyStart.Location = New System.Drawing.Point(6, 16)
        Me.btnHotkeyStart.Name = "btnHotkeyStart"
        Me.btnHotkeyStart.Size = New System.Drawing.Size(63, 23)
        Me.btnHotkeyStart.TabIndex = 1
        Me.btnHotkeyStart.Text = "F4"
        Me.btnHotkeyStart.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 20)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(77, 369)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Purpose"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Stop Hotkey"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Start Hotkey"
        '
        'tbpgHelp
        '
        Me.tbpgHelp.Location = New System.Drawing.Point(4, 22)
        Me.tbpgHelp.Name = "tbpgHelp"
        Me.tbpgHelp.Size = New System.Drawing.Size(794, 430)
        Me.tbpgHelp.TabIndex = 3
        Me.tbpgHelp.Text = "Help"
        Me.tbpgHelp.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnStart.Location = New System.Drawing.Point(808, 27)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(88, 31)
        Me.btnStart.TabIndex = 2
        Me.btnStart.Text = "Start Selected"
        Me.btnStart.UseVisualStyleBackColor = False
        '
        'lblStartHotkey
        '
        Me.lblStartHotkey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStartHotkey.AutoSize = True
        Me.lblStartHotkey.Location = New System.Drawing.Point(829, 9)
        Me.lblStartHotkey.Name = "lblStartHotkey"
        Me.lblStartHotkey.Size = New System.Drawing.Size(39, 13)
        Me.lblStartHotkey.TabIndex = 4
        Me.lblStartHotkey.Text = "hotkey"
        Me.lblStartHotkey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnExit.Location = New System.Drawing.Point(808, 389)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(88, 56)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnStop
        '
        Me.btnStop.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnStop.Location = New System.Drawing.Point(808, 77)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(88, 31)
        Me.btnStop.TabIndex = 5
        Me.btnStop.Text = "Stop Selected"
        Me.btnStop.UseVisualStyleBackColor = False
        '
        'lblStopHotkey
        '
        Me.lblStopHotkey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStopHotkey.AutoSize = True
        Me.lblStopHotkey.Location = New System.Drawing.Point(829, 61)
        Me.lblStopHotkey.Name = "lblStopHotkey"
        Me.lblStopHotkey.Size = New System.Drawing.Size(39, 13)
        Me.lblStopHotkey.TabIndex = 6
        Me.lblStopHotkey.Text = "hotkey"
        Me.lblStopHotkey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button1.Location = New System.Drawing.Point(808, 127)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 34)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Pause Un-Pause"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'lblPauseHotkey
        '
        Me.lblPauseHotkey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPauseHotkey.AutoSize = True
        Me.lblPauseHotkey.Location = New System.Drawing.Point(829, 111)
        Me.lblPauseHotkey.Name = "lblPauseHotkey"
        Me.lblPauseHotkey.Size = New System.Drawing.Size(39, 13)
        Me.lblPauseHotkey.TabIndex = 8
        Me.lblPauseHotkey.Text = "hotkey"
        Me.lblPauseHotkey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'filedialogLoadMacroMain
        '
        Me.filedialogLoadMacroMain.FileName = "OpenFileDialog1"
        '
        'btnTest
        '
        Me.btnTest.Location = New System.Drawing.Point(815, 253)
        Me.btnTest.Name = "btnTest"
        Me.btnTest.Size = New System.Drawing.Size(75, 77)
        Me.btnTest.TabIndex = 9
        Me.btnTest.Text = "test"
        Me.btnTest.UseVisualStyleBackColor = True
        '
        'filedialogSaveMacroMain
        '
        Me.filedialogSaveMacroMain.FileName = "Macro"
        Me.filedialogSaveMacroMain.Filter = "Text Files(*.txt) | *.txt"
        '
        'DatabaseLoadedMacrosDataSet
        '
        Me.DatabaseLoadedMacrosDataSet.DataSetName = "databaseLoadedMacrosDataSet"
        Me.DatabaseLoadedMacrosDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DatabaseLoadedMacrosDataSetBindingSource
        '
        Me.DatabaseLoadedMacrosDataSetBindingSource.DataSource = Me.DatabaseLoadedMacrosDataSet
        Me.DatabaseLoadedMacrosDataSetBindingSource.Position = 0
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(902, 457)
        Me.Controls.Add(Me.btnTest)
        Me.Controls.Add(Me.lblPauseHotkey)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblStopHotkey)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.tbMenu)
        Me.Controls.Add(Me.lblStartHotkey)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "MainForm"
        Me.Text = "Du It For Ya"
        Me.tbMenu.ResumeLayout(False)
        Me.tbpgMacro.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tbpgLoad.ResumeLayout(False)
        Me.tbpgLoad.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.gridLoadedMacros, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gridFavMacros, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gridSavedMacros, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbpgSettings.ResumeLayout(False)
        Me.tabSettings.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.LoadedMacrosDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FavoriteMacrosDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DatabaseLoadedMacrosDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DatabaseLoadedMacrosDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtInput As TextBox
    Friend WithEvents lblInput As Label
    Friend WithEvents tbMenu As TabControl
    Friend WithEvents tbpgMacro As TabPage
    Friend WithEvents tbpgSettings As TabPage
    Friend WithEvents btnExit As Button
    Friend WithEvents btnStart As Button
    Friend WithEvents tbpgLoad As TabPage
    Friend WithEvents lblStartHotkey As Label
    Friend WithEvents tbpgHelp As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblMacroname As Label
    Friend WithEvents chkLoop As CheckBox
    Friend WithEvents btnStop As Button
    Friend WithEvents lblStopHotkey As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents lblPauseHotkey As Label
    Friend WithEvents tabSettings As TabControl
    Friend WithEvents tbSettings As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnHotkeyStart As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnHotkeyStop As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents btnCapture As Button
    Friend WithEvents txtWindowCaption As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnUnFav As Button
    Friend WithEvents btnFav As Button
    Friend WithEvents btnSaveLoadout As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents filedialogLoadMacroMain As OpenFileDialog
    Friend WithEvents gridFavMacros As DataGridView
    Friend WithEvents gridSavedMacros As DataGridView
    Friend WithEvents btnRemoveSavedMacro As Button
    Friend WithEvents btnLoadSavedMacro As Button
    Friend WithEvents gridLoadedMacros As DataGridView
    Friend WithEvents btnLoadMacro As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnSaveSelectedMacro As Button
    Friend WithEvents btnLoadSelectedMacro As Button
    Friend WithEvents btnTest As Button
    Friend WithEvents filedialogSaveMacroMain As SaveFileDialog
    Friend WithEvents btnDefaultSettings As Button
    Friend WithEvents btnSaveSettings As Button
    Friend WithEvents FavoriteMacrosDataSetBindingSource As BindingSource
    Friend WithEvents LoadedMacrosDataSetBindingSource As BindingSource
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents File_Location_Loaded As DataGridViewTextBoxColumn
    Friend WithEvents State As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents File_Location As DataGridViewTextBoxColumn
    Friend WithEvents DatabaseLoadedMacrosDataSetBindingSource As BindingSource
    Friend WithEvents DatabaseLoadedMacrosDataSet As databaseLoadedMacrosDataSet
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents FileLocation As DataGridViewTextBoxColumn
    Friend WithEvents chkLoop1 As CheckBox
    Friend WithEvents btnStop1 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents label1231 As Label
    Friend WithEvents btnStart1 As Button
End Class
