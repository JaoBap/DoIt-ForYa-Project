﻿CREATE TABLE [dbo].[Table]
(
	[Macro] TEXT NOT NULL PRIMARY KEY
)
