﻿Imports System.ComponentModel
Imports System.Drawing.Imaging
Imports System.Drawing.Text
Imports System.IO
Imports System.Runtime.CompilerServices.RuntimeHelpers
Imports System.Runtime.DesignerServices
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.Security.Cryptography.X509Certificates
Imports System.Security.Principal
Imports System.Text
Imports System.Threading
Imports System.Windows
Imports System.Windows.Forms.DataFormats
Imports System.Windows.Forms.Design
Imports System.Windows.Forms.VisualStyles
Imports GregsStack.InputSimulatorStandard.Native
Imports Microsoft.VisualBasic.ApplicationServices
Imports System.Data
''' <summary>
''' Issue Board:
''' 
''' - Cant input into unfocused application with current module (4th key input iteration, input simulator greg stacks)
''' - Function keys F1 F2 etc arent working for hotkeys
''' - Ctrl alt, shift, etc, doenst display on hotkey buttons correctly in text box
''' - Hold key only working in games
''' </summary>
Public Class MainForm
#Region "variables"
    Dim strFileLocation As String = "test.txt" 'string for file location
    Dim strWindowName As String 'string for window name
    Dim intProcID = 0 'process id for window desired
    Public Shared boolBoxLoop As Boolean 'boolean to see if u want loop to stop (Can be used to stop loops in other subs)

#End Region

#Region "Selecting Window"
    'For selecting macro window
    Private Declare Function SetForegroundWindow Lib "user32" Alias "SetForegroundWindow" (ByVal hwnd As IntPtr) As Integer
    Dim hwnd As Integer
    Dim strWindowCaption As String = "No window!"
    Private Sub btnCapture_Click(sender As Object, e As EventArgs) Handles btnCapture.Click
        'Grabs window caption
        txtWindowCaption.Text = "Scanning for 2 seconds... (Will beep when window is captured, Open Desired Window!)" 'Friendly notification saying looking for window
        'Grabs window handle
        hwnd = classGetWindow.Capture_hWnd() 'waits five seconds before setting focused window as desired window
        strWindowCaption = classGetWindow.Capture_Caption(hwnd) 'returns hwnd
        txtWindowCaption.Text = strWindowCaption 'sets textbox text as window caption
        'should play a sound when done
        My.Computer.Audio.PlaySystemSound(
        System.Media.SystemSounds.Beep)
    End Sub
#End Region

#Region "Core Macro"
    'Main Macro
    Private Declare Function VkKeyScanEx Lib "user32.dll" Alias "VkKeyScanExA" (ByVal ch As Char, ByVal hkl As Long) As Integer

    Public Sub spu_macro(ByVal Macrodirectory0 As String)
        If hwnd > 0 Then
            SetForegroundWindow(hwnd) 'sets window as active and to front                           *(TEMP FIX)*
            If IO.File.Exists(Macrodirectory0) Then 'Checks if directory exists then Declares and savesmacro file with variable above as its file directory
                Dim Macro0 As IO.StreamReader
                Macro0 = IO.File.OpenText(Macrodirectory0)
                lblMacroname.Text = Macrodirectory0
                txtInput.Text = Macro0.ReadToEnd 'Reads Macro text file that is "loaded" (D)A[5](U)A is hold A down, wait five seconds, stop holding A down

                Dim chrAMacro0() As Char = txtInput.Text.ToCharArray
                Dim boolParanthesis = False 'boolean to see if input has paranethesis
                Dim boolBrackets = False 'Boolean to see if input has brackets
                Dim strInterval0 As String = "0" 'declares int for interval input
                Dim boolholddownislooping As Boolean 'boolean for holddown check from previous if check
                Dim charPrev As Char 'for previous char in i loop

                For Each i In chrAMacro0 'For each loop, that checks each character in chararray for if statements for Paranthesis, brackets, letter
                    Dim VK As VirtualKeyCode = VkKeyScanEx(i, vbNull)
                    If i = "(" Or i = ")" Then 'If paranthesis in char
                        boolParanthesis = True
                    ElseIf i = "[" Or i = "]" Then 'If brackets in char
                        boolBrackets = True
                    Else 'If letter or number (first checks if paranethesis or brackets was previous char
                        If boolBrackets = False And boolParanthesis = False Then 'sees if its a desired letter input
                            'SendKeys.Send(i) Old way of sending text
                            '(D)A[5](U)A
                            If boolholddownislooping = True Then 'Hold Key Down
                                classInput.SendKeystrokeDown(hwnd, KeyEventType.WM_KEYDOWN, VK, vbNull, vbNull)
                                charPrev = i
                            ElseIf False Then 'For press key
                                classInput.SendKeystrokeUp(hwnd, KeyEventType.WM_KEYUP, VK, vbNull, vbNull)
                            End If
                        End If
                    End If
                    If boolBrackets = True Then 'checks if i is brackets for interval time
                        If IsNumeric(i) Then 'checks if number, if so it inputs it (Issue with double or triple digit numbers)
                            strInterval0 = strInterval0 + i 'Adds current string to next string, not mathamatically
                        ElseIf i = "]" Then
                            Sleep.wait(strInterval0) 'Interval Code, gets string from txt, times it by 1000, turning it into a seconds
                            boolBrackets = False
                        End If
                    End If
                    If boolParanthesis = True Then 'checks if i is paranthesis for hold down
                        If i = "D" Then 'if to press down
                            boolholddownislooping = True
                        ElseIf i = "U" Then 'if to press up
                            boolholddownislooping = False 'boolean should change to false after this is done
                            VK = VkKeyScanEx(charPrev, vbNull)
                            classInput.SendKeystrokeUp(hwnd, KeyEventType.WM_KEYDOWN, VK, vbNull, vbNull) 'to let key go
                        ElseIf i = ")" Then 'if char is an end paranthesis
                            boolParanthesis = False
                        End If
                    End If
                Next
                Macro0.Close()
            Else
                MsgBox("Macro or text file does not exist or is not loaded/selected!")
            End If
        Else
            MsgBox("No window selected!")
        End If

    End Sub
    'Loop macro
    Public Sub macroLoop()
        If boolBoxLoop = True Then 'if check to see if false
            Do While boolBoxLoop = True 'actual loop to loop main function until a stop command is entered, might have to add stop command to EVERY loop in here
                spu_macro(strFileLocation)
            Loop
        Else
            spu_macro(strFileLocation)
        End If
    End Sub
    'button start
#End Region

#Region " basic form tools/items"
    Public Sub btnStart0_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        macroLoop() 'Starts macro by checking if loop is checked
    End Sub
    'button stop
    Public Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        boolBoxLoop = False
    End Sub
    'loop checkbox
    Private Sub chkLoop_CheckedChanged(sender As Object, e As EventArgs) Handles chkLoop.CheckedChanged
        If chkLoop.Checked = True Then 'if loop for looping macro
            boolBoxLoop = True
        Else
            boolBoxLoop = False
        End If
    End Sub
    'exit button
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'declares new var as dialogresult type
        Dim dlgButton As DialogResult
        'sets new var as message box for dialog
        dlgButton =
            MessageBox.Show("Exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2)
        My.Computer.Audio.PlaySystemSound(
        System.Media.SystemSounds.Beep)
        If dlgButton = DialogResult.Yes Then 'if statement to see if return value for dialog is yes, if yes than close program
            Hotkey.unregisterHotkeys(Me)
            Me.Close()
        End If
    End Sub

#End Region

#Region "On Form Load"
    'System wide hotkey event handling
    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        If m.Msg = Hotkey.WM_HOTKEY Then
            Hotkey.handleHotKeyEvent(m.WParam)
        End If
        MyBase.WndProc(m)
    End Sub
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub

#End Region

#Region "Slot System for macro page tab"

#Region "Slotted Macros Datagrid View"
    'Add Macros by double clicking in macro pages datagridview's

    'Remove Macros by double clicking in slotted macro datagridview

#End Region

#Region "Slot 1"
    'Load macro into slot

    'register hotkey functions for each slots hotkeys for start and stop
#Region "Hotkey Start Macro: 2000"
    'Click button to get hotkey
    Private Sub btnstart1_click(sender As Object, e As EventArgs) Handles btnStart1.Click 'Edit
        boolGetHotkey = True
        btnStart1.Text = "Press Key" 'Edit
        intHotkeyGetModifier = 0
        Hotkey.unregisterHotkey(Me, 2000) 'Edit
    End Sub

    '1 Gets modifier
    Private Sub btnstart1_KeyDown(sender As Object, e As KeyEventArgs) Handles btnStart1.KeyDown 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyDown(e) 'edit
            btnStart1.Text = btnText 'edit
        End If
    End Sub
    '2 Gets key
    Private Sub btnstart1_KeyUp(sender As Object, e As KeyEventArgs) Handles btnStart1.KeyUp 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyUp(e, Me, 2000) 'edit
            btnStart1.Text = btnText 'edit
        End If
    End Sub

#End Region
#Region "Hotkey to Stop Macro: 2001"
    'Click button to get hotkey
    Private Sub btnstop1_Click(sender As Object, e As EventArgs) Handles btnStop1.Click 'Edit
        boolGetHotkey = True
        btnStop1.Text = "Press Key" 'Edit
        intHotkeyGetModifier = 0
        Hotkey.unregisterHotkey(Me, 2001) 'Edit
    End Sub

    '1 Gets modifier
    Private Sub btnstop1_KeyDown(sender As Object, e As KeyEventArgs) Handles btnStop1.KeyDown 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyDown(e)
            btnStop1.Text = btnText 'edit
        End If
    End Sub
    '2 Gets key
    Private Sub btnstop1_KeyUp(sender As Object, e As KeyEventArgs) Handles btnStop1.KeyUp 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyUp(e, Me, 2001) 'edit
            btnStop1.Text = btnText 'edit
        End If
    End Sub
#End Region
    'Function to start macro with loop

#End Region


#End Region

#Region "load/Save Macro Page Form Tools/items"
    Dim strLoadMacroList As New List(Of String)
    Private Sub btnRemoveSavedMacro_Click(sender As Object, e As EventArgs) Handles btnRemoveSavedMacro.Click
        'Message Prompt if user wants to remove macro to double check
        Dim dlgButton As DialogResult = MessageBox.Show("Remove Row?", "Remove Row", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2)
        My.Computer.Audio.PlaySystemSound(System.Media.SystemSounds.Beep)
        If dlgButton = DialogResult.Yes Then 'if statement to see if return value for dialog is yes
            'Macro is removed from text box
            Dim intRow As Integer = gridSavedMacros.CurrentCell.RowIndex
            gridSavedMacros.Rows.RemoveAt(intRow)
        End If
        'What ever is in the text box is then saved for future use

    End Sub
    Private Sub btnLoadSavedMacro_Click(sender As Object, e As EventArgs) Handles btnLoadSavedMacro.Click
        'Opens file browser to select which macro you wanna add
        filedialogLoadMacroMain.ShowDialog()
        'need to find a way to save whats in the data grid table to the database
        gridSavedMacros.Rows.Add(filedialogLoadMacroMain.SafeFileName, filedialogLoadMacroMain.FileName)
    End Sub
    'Saving Changes
    Private Sub btnSaveLoadout_Click(sender As Object, e As EventArgs) Handles btnSaveLoadout.Click
        'Message Prompt if user wants to save to double check
        Dim dlgButton As DialogResult = MessageBox.Show("Save?", "Save", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2)
        My.Computer.Audio.PlaySystemSound(System.Media.SystemSounds.Beep)
        If dlgButton = DialogResult.Yes Then 'if statement to see if return value for dialog is yes
            'Save everything in datagridviews to database, overwriting previous save

            'Database way: Overwrite data in database with data in griddataview

            'CLUELESS on how to save persistently
        End If
    End Sub
    'Favorite Tabs
    Private Sub btnFav_Click(sender As Object, e As EventArgs) Handles btnFav.Click
        If gridSavedMacros.SelectedCells.Count >= 1 Then
            'Moves selected macro in macro load list to favorites
            gridFavMacros.Rows.Add(gridSavedMacros.CurrentCell.Value)
            'removes row from load grid
            Dim intRow As Integer = gridSavedMacros.CurrentCell.RowIndex
            'removes selected macro in macro load list
            gridSavedMacros.Rows.RemoveAt(intRow)
        End If
    End Sub

    Private Sub btnUnFav_Click(sender As Object, e As EventArgs) Handles btnUnFav.Click
        If gridFavMacros.SelectedCells.Count >= 1 Then
            'Moves selected macro in macro load list to favorites
            gridSavedMacros.Rows.Add(gridFavMacros.CurrentCell.Value)
            'removes row from laod grid
            Dim intRow As Integer = gridFavMacros.CurrentCell.RowIndex
            'removes selected macro in macro load list
            gridFavMacros.Rows.RemoveAt(intRow)
        End If
    End Sub

    'load main macro in macro tab
    Private Sub btnLoadSelectedMacro_Click(sender As Object, e As EventArgs) Handles btnLoadSelectedMacro.Click
        filedialogLoadMacroMain.ShowDialog()
        strFileLocation = filedialogLoadMacroMain.FileName
        lblMacroname.Text = filedialogLoadMacroMain.FileName

        If IO.File.Exists(strFileLocation) Then 'Checks if directory exists then Declares and savesmacro file with variable above as its file directory
            Dim Macro0 As IO.StreamReader
            Macro0 = IO.File.OpenText(strFileLocation)
            txtInput.Text = Macro0.ReadToEnd 'Reads Macro text file that is "loaded" (D)A[5](U)A is hold A down, wait five seconds, stop holding A down
            Macro0.Close()
        End If
    End Sub
    'Save main macro in macro tab
    Private Sub btnSaveSelectedMacro_Click(sender As Object, e As EventArgs) Handles btnSaveSelectedMacro.Click
        filedialogSaveMacroMain.ShowDialog()
        Dim writetxtfile As New StreamWriter(filedialogSaveMacroMain.FileName)
        writetxtfile.WriteLine(txtInput.Text)
        writetxtfile.Close()
    End Sub


    'Starts said macro in saved macro list
    Private Sub gridSavedMacros_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridSavedMacros.CellContentClick
        'adds macro to loaded macros into available slot

        'Each slot has it's own hotkey for start/pause 

    End Sub
#End Region

#Region "Settings"

#Region "Hotkey Settings"
    'to set hotkey for start
#Region "Hotkey Start Macro ALL"
    'Click button to get hotkey
    Private Sub btnHotkeyStart_Click(sender As Object, e As EventArgs) Handles btnHotkeyStart.Click 'Edit
        boolGetHotkey = True
        btnHotkeyStart.Text = "Press Key" 'Edit
        intHotkeyGetModifier = 0
        Hotkey.unregisterHotkey(Me, 1) 'Edit
    End Sub

    '1 Gets modifier
    Private Sub btnHotkeyStart_KeyDown(sender As Object, e As KeyEventArgs) Handles btnHotkeyStart.KeyDown 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyDown(e)
            btnHotkeyStart.Text = btnText 'edit
        End If
    End Sub
    '2 Gets key
    Private Sub btnHotkeyStart_KeyUp(sender As Object, e As KeyEventArgs) Handles btnHotkeyStart.KeyUp 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyUp(e, Me, 1) 'edit
            btnHotkeyStart.Text = btnText 'edit
        End If
    End Sub

#End Region
    'to set hotkey to stop
#Region "Stop Macro ALL"
    'Click button to get hotkey
    Private Sub btnHotkeyStop_Click(sender As Object, e As EventArgs) Handles btnHotkeyStop.Click 'Edit
        boolGetHotkey = True
        btnHotkeyStop.Text = "Press Key" 'Edit
        intHotkeyGetModifier = 0
        Hotkey.unregisterHotkey(Me, 2) 'Edit
    End Sub

    '1 Gets modifier
    Private Sub btnHotkeyStop_KeyDown(sender As Object, e As KeyEventArgs) Handles btnHotkeyStop.KeyDown 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyDown(e)
            btnHotkeyStop.Text = btnText 'edit
        End If
    End Sub
    '2 Gets key
    Private Sub btnHotkeyStop_KeyUp(sender As Object, e As KeyEventArgs) Handles btnHotkeyStop.KeyUp 'Edit
        If boolGetHotkey = True Then
            Hotkey.getHotkeyButtonKeyUp(e, Me, 2) 'edit
            btnHotkeyStop.Text = btnText 'edit
        End If
    End Sub
#End Region

#End Region

#End Region

#Region " Testing "
    Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Integer, ByVal Msg As Integer, ByVal wParam As Long, ByVal lParam As Long) As Integer
    Private Sub btnTest_Click(sender As Object, e As EventArgs) Handles btnTest.Click
        'SendMessage(hwnd, Keys.I, 0, Text)

    End Sub

#End Region
End Class